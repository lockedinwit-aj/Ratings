import { getStore } from '@netlify/blobs';
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers});
export default async(request)=>{
  if(request.method!=='GET')return reply(405,{error:'Method Not Allowed'});
  const code=new URL(request.url).searchParams.get('code')?.trim().toUpperCase()||'';
  if(!/^AJ-[A-F0-9]{24}$/.test(code))return reply(404,{error:'Order Not Found. Check Your Code And Try Again.'});
  try{
    const item=await getStore('woodwork-orders').get(code,{type:'json'});
    if(!item||!Number.isInteger(item.stage)||item.stage<0||item.stage>4)return reply(404,{error:'Order Not Found. Check Your Code And Try Again.'});
    return reply(200,{code,stage:item.stage,updatedAt:item.updatedAt});
  }catch(e){console.error('Order status error',e);return reply(500,{error:'Order Tracking Is Temporarily Unavailable.'})}
};
