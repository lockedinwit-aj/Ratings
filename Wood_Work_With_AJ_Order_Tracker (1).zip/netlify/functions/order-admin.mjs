import { getStore } from '@netlify/blobs';
import { timingSafeEqual } from 'node:crypto';
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers});
const allowed=['Deposit Received','Design Confirmed','In Production','Painting & Finishing','Ready For Pickup / Shipping'];
function authorized(request){
 const expected=process.env.ORDER_ADMIN_SECRET;
 const provided=request.headers.get('x-admin-secret')||'';
 if(!expected||expected.length<24||!provided)return false;
 const a=Buffer.from(provided),b=Buffer.from(expected);
 return a.length===b.length&&timingSafeEqual(a,b);
}
export default async(request)=>{
 if(!authorized(request))return reply(401,{error:'Unauthorized. Check Your Admin Password.'});
 if(request.method!=='GET'&&request.method!=='POST')return reply(405,{error:'Method Not Allowed'});
 try{
  const store=getStore('woodwork-orders');
  if(request.method==='GET'){
   const {blobs}=await store.list({paginate:false});
   const orders=(await Promise.all(blobs.slice(0,500).map(async b=>{try{return await store.get(b.key,{type:'json'})}catch{return null}}))).filter(Boolean).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
   return reply(200,{orders});
  }
  const body=await request.text();if(body.length>2000)return reply(413,{error:'Request Too Large.'});
  const input=JSON.parse(body);const action=input.action;
  if(action==='create'){
   const label=String(input.label||'').trim().slice(0,60);
   if(!label)return reply(400,{error:'Enter A Short Internal Order Label.'});
   const code='AJ-'+Array.from(crypto.getRandomValues(new Uint8Array(12)),b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();
   const now=new Date().toISOString();const order={code,label,stage:0,createdAt:now,updatedAt:now};
   await store.setJSON(code,order);return reply(201,{order});
  }
  if(action==='update'){
   const code=String(input.code||'').toUpperCase(),stage=Number(input.stage);
   if(!/^AJ-[A-F0-9]{24}$/.test(code)||!Number.isInteger(stage)||stage<0||stage>=allowed.length)return reply(400,{error:'Invalid Order Or Stage.'});
   const existing=await store.get(code,{type:'json'});
   if(!existing)return reply(404,{error:'Order Not Found.'});
   const order={...existing,stage,updatedAt:new Date().toISOString()};await store.setJSON(code,order);return reply(200,{order});
  }
  return reply(400,{error:'Unknown Action.'});
 }catch(e){console.error('Admin order error',e);return reply(500,{error:'Could Not Complete Request.'})}
};
