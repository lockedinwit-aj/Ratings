WOOD WORK WITH AJ — CUSTOMER REVIEWS

IMPORTANT: This Version Requires Netlify Functions. Uploading The ZIP With Netlify Drop Alone Will NOT Activate The Review Backend.

To Publish:
1. Unzip This Folder On A Computer.
2. Put The Entire Folder Contents Into A GitHub Repository (Including netlify/functions/reviews.mjs, package.json, netlify.toml, And index.html).
3. In Your Existing Netlify Site, Link That Repository Under Project Configuration > Build & Deploy > Continuous Deployment.
4. Deploy The Repository To Your EXISTING Site To Keep woodworkwithaj.netlify.app. Netlify Installs @netlify/blobs And Builds The Function.
5. Test Submitting A Review From The Live Website, Then Refresh On Another Device.

Reviews Are Public Immediately. No Moderation Dashboard Is Included. Avoid Publishing Sensitive Personal Information. Spam Protection Is Basic Only. Netlify Blobs Is Used To Persist Reviews. The Static HTML Alone Cannot Save Reviews.
